import React, { useState } from 'react';
import { DataGrid, GridColDef, GridRowsProp } from '@mui/x-data-grid';
import { ButtonGroup, Button } from '@mui/material';
import Header from './Header';

interface CustomData {
  id: number;
  sourceType: string;
  rule: string;
  delete: string;
}

const initialData: CustomData[] = [
  { id: 1, sourceType: 'Par Roll', rule: 'LEN(@CUSP)*3', delete: '' },
  { id: 2, sourceType: 'Cost Roll', rule: '@SIDE <> "L"', delete: '' },
  { id: 3, sourceType: 'Par Roll', rule: '@SIDE <> "L"', delete: '' },
  { id: 4, sourceType: 'Par Roll', rule: 'LEN(@CUSP)*3', delete: '' },
];

const Exclusions: React.FC = () => {
  const [rows, setRows] = useState<GridRowsProp>(initialData);

  const loadAll = () => {
    setRows(initialData);
  };

  const columns: GridColDef[] = [
    { field: 'id', headerName: 'Id', width: 90, sortable: false },
    { field: 'sourceType', headerName: 'Source Type', width: 300, sortable: false },
    { field: 'rule', headerName: 'Rule', width: 300, sortable: false },
    { field: 'delete', headerName: 'Delete', width: 100, sortable: false },
  ];

  return (
    <div>
      <Header title={'Mapping - Custom Data'} />
      <div style={{ margin: '0 10px' }}>
        <ButtonGroup variant='contained' style={{ marginBottom: '20px' }}>
          <Button onClick={loadAll}>Load</Button>
          <Button>Sort</Button>
          <Button>Clear</Button>
          <Button>Validate</Button>
          <Button>Save</Button>
          <Button>View Rule Tags</Button>
        </ButtonGroup>
        <DataGrid rows={rows} columns={columns} hideFooter disableColumnMenu />
      </div>
    </div>
  );
};

export default Exclusions;
