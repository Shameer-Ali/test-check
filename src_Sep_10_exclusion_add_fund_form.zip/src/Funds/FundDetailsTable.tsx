import React, { useState } from 'react';
import { DataGrid, GridColDef, GridRowsProp } from '@mui/x-data-grid';
import { ButtonGroup, Button, Dialog, DialogTitle, DialogContent, DialogActions, TextField, MenuItem } from '@mui/material';
import { FiChevronDown } from 'react-icons/fi'; // React Icons for down arrow
import Header from './Header';

interface Fund {
  id: number;
  fundId: string;
  baseCurrency: string;
  fundDescription: string;
  fundType: string;
  compositeId: string;
  isActive: boolean;
}

const initialData: Fund[] = [
  { id: 1, fundId: 'WLCD', baseCurrency: 'USD', fundDescription: 'Willow Tree Capital Fund', fundType: 'Composite', compositeId: 'WLCD', isActive: true },
  { id: 2, fundId: 'WLCH', baseCurrency: 'USD', fundDescription: 'Willow Tree Capital Fund CH', fundType: 'Sleeve', compositeId: 'WLCD', isActive: false },
  { id: 3, fundId: 'WLCG', baseCurrency: 'USD', fundDescription: 'Willow Tree Capital Fund G', fundType: 'Standard', compositeId: 'WLCD', isActive: true },
  { id: 4, fundId: 'WLCC', baseCurrency: 'USD', fundDescription: 'Willow Tree Capital Fund C', fundType: 'Composite', compositeId: 'WLCD', isActive: false },
  { id: 5, fundId: 'WLDA', baseCurrency: 'USD', fundDescription: 'Willow Tree Capital Fund A', fundType: 'Sleeve', compositeId: 'WLCD', isActive: true },
  { id: 6, fundId: 'WLDF', baseCurrency: 'USD', fundDescription: 'Willow Tree Capital Fund F', fundType: 'Standard', compositeId: 'WLCD', isActive: false },
  { id: 7, fundId: 'WLDM', baseCurrency: 'USD', fundDescription: 'Willow Tree Capital Fund M', fundType: 'Standard', compositeId: 'WLCD', isActive: true },
  { id: 8, fundId: 'WLDK', baseCurrency: 'USD', fundDescription: 'Willow Tree Capital Fund K', fundType: 'Standard', compositeId: 'WLCD', isActive: false },
  { id: 9, fundId: 'WLDO', baseCurrency: 'USD', fundDescription: 'Willow Tree Capital Fund P', fundType: 'Composite', compositeId: 'WLCD', isActive: true },
  { id: 10, fundId: 'WLZO', baseCurrency: 'USD', fundDescription: 'Willow Tree Capital Fund O', fundType: 'Sleeve', compositeId: 'WLCD', isActive: false },
];


const FundDetailsTable: React.FC = () => {
  const [rows, setRows] = useState<GridRowsProp>(initialData);
  const [open, setOpen] = useState(false);
  const [formData, setFormData] = useState<Fund>({
    id: 0,
    fundId: '',
    baseCurrency: '',
    fundDescription: '',
    fundType: '',
    compositeId: '',
    isActive: true,
  });

  const handleOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
    setFormData({
      id: 0,
      fundId: '',
      baseCurrency: '',
      fundDescription: '',
      fundType: '',
      compositeId: '',
      isActive: true,
    });
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleSave = () => {
    if (formData.id === 0) {
      // Adding new fund
      const newFund = {
        ...formData,
        id: rows.length + 1, // Set id as the next number
      };
      setRows([...rows, newFund]);
    } else {
      // Updating existing fund
      const updatedRows = rows.map((row) =>
        row.id === formData.id ? formData : row
      );
      setRows(updatedRows);
    }
    handleClose();
  };

  const handleEdit = (id: number) => {
    const rowToEdit: any = rows.find((row) => row.id === id);
    if (rowToEdit) {
      setFormData(rowToEdit);
      setOpen(true);
    }
  };

  const columns: GridColDef[] = [
    { field: 'id', headerName: 'Id', width: 90, sortable: false },
    { field: 'fundId', headerName: 'Fund Id', width: 150, sortable: false },
    { field: 'baseCurrency', headerName: 'Base Currency', width: 150, sortable: false },
    { field: 'fundDescription', headerName: 'Fund Description', width: 200, sortable: false },
    {
      field: 'fundType',
      headerName: 'Fund Type',
      width: 150,
      renderCell: (params) => (
        <div style={{ display: 'flex', alignItems: 'center' }}>
          {params.value} <FiChevronDown style={{ marginLeft: '5px' }} />
        </div>
      ),
    },
    { field: 'compositeId', headerName: 'Composite Id', width: 150, sortable: false },
    {
      field: 'isActive',
      headerName: 'Is Active',
      width: 150,
      renderCell: (params) => (
        <div style={{ display: 'flex', alignItems: 'center' }}>
          {params.value ? 'True' : 'False'}{' '}
          <FiChevronDown style={{ marginLeft: '5px' }} />
        </div>
      ),
    },
    {
      field: 'actions',
      headerName: 'Actions',
      width: 150,
      renderCell: (params) => (
        <Button onClick={() => handleEdit(params.row.id)}>Edit</Button>
      ),
    },
  ];

  return (
    <div>
      <Header title={'Mapping - Funds'} />
      <div style={{ margin: '0 10px' }}>
        <ButtonGroup variant='contained' style={{ marginBottom: '20px' }}>
          <Button onClick={handleOpen}>Add Fund</Button>
        </ButtonGroup>

        <DataGrid rows={rows} columns={columns} hideFooter disableColumnMenu />

        {/* Dialog for Add/Edit */}
        <Dialog open={open} onClose={handleClose}>
          <DialogTitle>{formData.id ? 'Edit Fund' : 'Add Fund'}</DialogTitle>
          <DialogContent>
            <TextField
              name="fundId"
              label="Fund Id"
              value={formData.fundId}
              onChange={handleChange}
              fullWidth
              margin="dense"
            />
            <TextField
              name="baseCurrency"
              label="Base Currency"
              value={formData.baseCurrency}
              onChange={handleChange}
              fullWidth
              margin="dense"
            />
            <TextField
              name="fundDescription"
              label="Fund Description"
              value={formData.fundDescription}
              onChange={handleChange}
              fullWidth
              margin="dense"
            />
            <TextField
              name="fundType"
              label="Fund Type"
              value={formData.fundType}
              onChange={handleChange}
              select
              fullWidth
              margin="dense"
            >
              <MenuItem value="Composite">Composite</MenuItem>
              <MenuItem value="Sleeve">Sleeve</MenuItem>
              <MenuItem value="Standard">Standard</MenuItem>
            </TextField>
            <TextField
              name="compositeId"
              label="Composite Id"
              value={formData.compositeId}
              onChange={handleChange}
              fullWidth
              margin="dense"
            />
            <TextField
              name="isActive"
              label="Is Active"
              value={formData.isActive}
              onChange={handleChange}
              select
              fullWidth
              margin="dense"
            >
              <MenuItem value={"True"}>True</MenuItem>
              <MenuItem value={"False"}>False</MenuItem>
            </TextField>
          </DialogContent>
          <DialogActions>
            <Button onClick={handleClose}>Cancel</Button>
            <Button onClick={handleSave}>Save</Button>
          </DialogActions>
        </Dialog>
      </div>
    </div>
  );
};

export default FundDetailsTable;
