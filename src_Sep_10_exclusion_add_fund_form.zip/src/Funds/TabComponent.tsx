import React, { useState } from 'react';
import { Box, Typography, Drawer, List, ListItem, ListItemText } from '@mui/material';
import FundDetailsTable from './FundDetailsTable';
import Header from './Header';
import Transactions from './Transactions';
import Securities from './Securities';
import Exclusions from './Exclusions';

interface DrawerComponentProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

function DrawerComponent(props: DrawerComponentProps) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`drawerpanel-${index}`}
      aria-labelledby={`drawer-${index}`}
      {...other}
    >
      {value === index && (
        <Box>
          <Typography>{children}</Typography>
        </Box>
      )}
    </div>
  );
}

const LayoutComponent: React.FC = () => {
  const [selectedIndex, setSelectedIndex] = useState(0);

  const handleListItemClick = (index: number) => {
    setSelectedIndex(index);
  };

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', height: '100vh' }}>
      {/* Fixed header */}
      <Box
        sx={{
          backgroundColor: '#001AFF',
          color: '#FFF',
          p: 2,
          textAlign: 'center',
          position: 'fixed',
          top: 0,
          left: 0,
          width: '100%',
          zIndex: 1000,
          display: 'flex',
          alignItems: 'center',
          gap: 2, // space between logo and text
        }}
      >
        <div style={{background:"#fff", padding: "5px"}}>
        <img
          src="https://www.statestreet.com/web/Homepage/images/state-street-logo-final.svg"
          alt="State Street Logo"
          style={{ height: '40px' }} // Adjust height as needed
        />
        </div>
        <Typography variant="h4" component="div">
          Blue State Street
        </Typography>
      </Box>

      {/* Main content with permanently open drawer and content area */}
      <Box sx={{ display: 'flex', flexGrow: 1, marginTop: '72px' }}>
        <Drawer
          variant="permanent"
          sx={{
            width: 240,
            flexShrink: 0,
            [`& .MuiDrawer-paper`]: { width: 240, boxSizing: 'border-box', marginTop: '87px' },
          }}
        >
          <List>
            {[ 'Main', 'Funds', 'Securities', 'Transactions', 'Exclusions'].map((text, index) => (
              <ListItem
                button
                key={text}
                selected={selectedIndex === index}
                onClick={() => handleListItemClick(index)}
              >
                <ListItemText primary={text} />
              </ListItem>
            ))}
          </List>
        </Drawer>

        <Box sx={{ flexGrow: 1 }}>
          <DrawerComponent value={selectedIndex} index={0}>
            <Header title={'Main Content'} />
          </DrawerComponent>
          <DrawerComponent value={selectedIndex} index={1}>
            <FundDetailsTable />
          </DrawerComponent>
          <DrawerComponent value={selectedIndex} index={2}>
            <Securities/>
          </DrawerComponent>
          <DrawerComponent value={selectedIndex} index={3}>
            <Transactions/>
          </DrawerComponent>
          <DrawerComponent value={selectedIndex} index={4}>
            <Exclusions/>
          </DrawerComponent>
        </Box>
      </Box>
    </Box>
  );
};

export default LayoutComponent;
