import React, { useState } from 'react';
import { DataGrid, GridColDef, GridRowsProp } from '@mui/x-data-grid';
import { ButtonGroup, Button, Menu, MenuItem } from '@mui/material';
import { FiChevronDown } from 'react-icons/fi'; // React Icons for down arrow
import Header from './Header';

interface Fund {
  id: number;
  fundId: string;
  baseCurrency: string;
  fundDescription: string;
  fundType: string;
  compositeId: string;
  isActive: boolean;
}

const initialData: Fund[] = [
  { id: 1, fundId: 'WLCD', baseCurrency: 'USD', fundDescription: 'Willow Tree Capital Fund', fundType: 'Composite', compositeId: 'WLCD', isActive: true },
  { id: 2, fundId: 'WLCH', baseCurrency: 'USD', fundDescription: 'Willow Tree Capital Fund CH', fundType: 'Sleeve', compositeId: 'WLCD', isActive: false },
  { id: 3, fundId: 'WLCG', baseCurrency: 'USD', fundDescription: 'Willow Tree Capital Fund G', fundType: 'Standard', compositeId: 'WLCD', isActive: true },
  { id: 4, fundId: 'WLCC', baseCurrency: 'USD', fundDescription: 'Willow Tree Capital Fund C', fundType: 'Composite', compositeId: 'WLCD', isActive: false },
  { id: 5, fundId: 'WLDA', baseCurrency: 'USD', fundDescription: 'Willow Tree Capital Fund A', fundType: 'Sleeve', compositeId: 'WLCD', isActive: true },
  { id: 6, fundId: 'WLDF', baseCurrency: 'USD', fundDescription: 'Willow Tree Capital Fund F', fundType: 'Standard', compositeId: 'WLCD', isActive: false },
  { id: 7, fundId: 'WLDM', baseCurrency: 'USD', fundDescription: 'Willow Tree Capital Fund M', fundType: 'Standard', compositeId: 'WLCD', isActive: true },
  { id: 8, fundId: 'WLDK', baseCurrency: 'USD', fundDescription: 'Willow Tree Capital Fund K', fundType: 'Standard', compositeId: 'WLCD', isActive: false },
  { id: 9, fundId: 'WLDO', baseCurrency: 'USD', fundDescription: 'Willow Tree Capital Fund P', fundType: 'Composite', compositeId: 'WLCD', isActive: true },
  { id: 10, fundId: 'WLZO', baseCurrency: 'USD', fundDescription: 'Willow Tree Capital Fund O', fundType: 'Sleeve', compositeId: 'WLCD', isActive: false },
];

const FundDetailsTable: React.FC = () => {
  const [rows, setRows] = useState<GridRowsProp>(initialData);

  const loadActive = () => {
    setRows(initialData.filter((fund) => fund.isActive));
  };

  const loadInActive = () => {
    setRows(initialData.filter((fund) => !fund.isActive));
  };

  const loadAll = () => {
    setRows(initialData);
  };

  const sortData = () => {
    const sortedData = [...rows].sort((a, b) =>
      a.fundId.localeCompare(b.fundId)
    );
    setRows(sortedData);
  };

  const clearData = () => {
    setRows(initialData);
  };

  const columns: GridColDef[] = [
    { field: 'id', headerName: 'Id', width: 90, sortable: false, editable: true },
    { field: 'fundId', headerName: 'Fund Id', width: 150, sortable: false, editable: true },
    { field: 'baseCurrency', headerName: 'Base Currency', width: 150, sortable: false, editable: true }, // Made Base Currency editable
    { field: 'fundDescription', headerName: 'Fund Description', width: 200, sortable: false, editable: true },
    {
      field: 'fundType',
      headerName: 'Fund Type',
      width: 150,
      editable: true,
      type: 'singleSelect',
      valueOptions: ['composite', 'sleeve', 'standard'],
      renderCell: (params) => (
        <div style={{ display: 'flex', alignItems: 'center' }}>
          {params.value} <FiChevronDown style={{ marginLeft: '5px' }} /> {/* Down Arrow Icon */}
        </div>
      ),
    },
    { field: 'compositeId', headerName: 'Composite Id', width: 150, sortable: false, editable: true },
    {
      field: 'isActive',
      headerName: 'Is Active',
      width: 150,
      editable: true,
      type: 'singleSelect',
      valueOptions: ['True', 'False'],
      renderCell: (params) => (
        <div style={{ display: 'flex', alignItems: 'center' }}>
          {params.value ? "True" : "False"} <FiChevronDown style={{ marginLeft: '5px' }} /> {/* Down Arrow Icon */}
        </div>
      ),
    },
  ];

  return (
    <div>
      <Header title={'Mapping - Funds'} />
      <div style={{ margin: '0 10px' }}>
        <ButtonGroup variant='contained' style={{ marginBottom: '20px' }}>
          {/* <Button onClick={loadActive}>Load</Button>
          <Button onClick={loadInActive}>Load In Active</Button> */}
          <Button onClick={loadAll}>Load</Button>
          {/* <Button onClick={sortData}>Sort</Button>
          <Button onClick={clearData}>Clear</Button> */}
          <Button>Add View</Button>
          <Button>Validate</Button>
        </ButtonGroup>

        <DataGrid rows={rows} columns={columns} hideFooter disableColumnMenu />
      </div>
    </div>
  );
};

export default FundDetailsTable;
