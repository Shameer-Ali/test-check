import React, { useState } from 'react';
import { DataGrid, GridColDef, GridRowsProp } from '@mui/x-data-grid';
import { ButtonGroup, Button } from '@mui/material';
import Header from './Header';

interface Security {
  id: number;
  cesip: string;
  oldCusip: string;
  cesipChange: string;
  loanXID: string;
  dealCode: string;
  localCurrency: string;
  investmentTypeCode: string;
  investmentTypeDescription: string;
  clientName: string;
  clientDescription: string;
}

const initialData: Security[] = [
    { id: 1, cesip: '836MLAB8', oldCusip: '1936MLA8', cesipChange: '9/27/2021', loanXID: 'LX199235', dealCode: '', localCurrency: 'USD', investmentTypeCode: 'BL', investmentTypeDescription: 'Bank Loan', clientName: 'RPX CORPORATION', clientDescription: '2021 INCREMENTAL TERM LOAN' },
    { id: 2, cesip: '5430WYIT', oldCusip: '943UWYET', cesipChange: '6/13/2022', loanXID: '3LX216562', dealCode: '', localCurrency: 'USD', investmentTypeCode: 'BL', investmentTypeDescription: 'Bank Loan', clientName: 'MNGMNT CNSLTNG AND INTEGRITY', clientDescription: '2022 1ST AMENDMENT DOTL' },
    { id: 3, cesip: '948JPYI15', oldCusip: '348JPYIS', cesipChange: '8/29/2023', loanXID: 'LX212541', dealCode: '', localCurrency: 'USD', investmentTypeCode: 'BL', investmentTypeDescription: 'Bank Loan', clientName: 'MRKTING ACQISTIN', clientDescription: '2023 A14 REFIN SPCL PURPS DOTL' },
    { id: 4, cesip: 'BA0000X67', oldCusip: 'BA0000X67', cesipChange: '1/16/2024', loanXID: 'LX212551', dealCode: '', localCurrency: 'USD', investmentTypeCode: 'BL', investmentTypeDescription: 'Bank Loan', clientName: 'TCFI OWL BUYER LLC', clientDescription: 'TERM LOAN D' },
    { id: 5, cesip: 'BA00021X8', oldCusip: 'BA0002KX8', cesipChange: '3/18/2024', loanXID: 'LX196170', dealCode: '', localCurrency: 'USD', investmentTypeCode: 'BL', investmentTypeDescription: 'Bank Loan', clientName: 'BEACON OSM HOLDINGS LLC', clientDescription: '2024 6TH AMEND DELAYED DRAW TL' },
    { id: 6, cesip: 'BA0003DW6', oldCusip: 'BA0003DW6', cesipChange: '4/15/2024', loanXID: 'LX202121', dealCode: '', localCurrency: 'USD', investmentTypeCode: 'BL', investmentTypeDescription: 'Bank Loan', clientName: 'SALT DENTAL COLLECTIVE LLC', clientDescription: 'GENERAL PURPOSE TERM LOAN' },
    { id: 7, cesip: 'BA0003J18', oldCusip: 'BA0003J18', cesipChange: '4/17/2024', loanXID: 'LX216561', dealCode: '', localCurrency: 'USD', investmentTypeCode: 'BL', investmentTypeDescription: 'Bank Loan', clientName: 'ROGERS MECHANICAL', clientDescription: '4TH AMENDMENT REVOLVER' },
    { id: 8, cesip: '70323JACS', oldCusip: '$48FFY14', cesipChange: '5/18/2023', loanXID: 'LX190593', dealCode: '', localCurrency: 'USD', investmentTypeCode: 'BL', investmentTypeDescription: 'Bank Loan', clientName: 'PATHSTONE FAMILY OFFICE', clientDescription: '2023 DELAY DRAW TERM LOAN' },
    { id: 9, cesip: '902WABB6', oldCusip: '902WABB6', cesipChange: '1/10/2024', loanXID: 'LX225853', dealCode: '', localCurrency: 'USD', investmentTypeCode: 'BL', investmentTypeDescription: 'Bank Loan', clientName: 'LINE OF CREDIT (CNBUSD)', clientDescription: 'LOC CNB' },
    { id: 10, cesip: '942YNPIS', oldCusip: '$42YNPIS', cesipChange: '7/2/2021', loanXID: 'LX189087', dealCode: '', localCurrency: 'USD', investmentTypeCode: 'BL', investmentTypeDescription: 'Bank Loan', clientName: 'VRC COMPANIES LLC', clientDescription: '2021 REVOLVER' },
    { id: 11, cesip: '844X22014', oldCusip: '344X22114', cesipChange: '12/23/2021', loanXID: 'LX196168', dealCode: '', localCurrency: 'USD', investmentTypeCode: 'BL', investmentTypeDescription: 'Bank Loan', clientName: 'HIGGINBOTHAM INSU AGENCY', clientDescription: '2021 INCREMENTAL DOTL' },
    { id: 12, cesip: '$48JNH114', oldCusip: '348JNH14', cesipChange: '8/25/2023', loanXID: '', dealCode: '', localCurrency: 'USD', investmentTypeCode: 'BL', investmentTypeDescription: 'Bank Loan', clientName: 'INTEGRITY MARKT ACQISITION', clientDescription: '2019 AMENDMENT N 14 INITIAL TL' },
    { id: 13, cesip: '9538KS112', oldCusip: '953BKS#2', cesipChange: '12/22/2022', loanXID: '', dealCode: '', localCurrency: 'USD', investmentTypeCode: 'BL', investmentTypeDescription: 'Bank Loan', clientName: 'DENTIVE CAPITAL LLC', clientDescription: 'FIRST LIEN DOTL' },
    { id: 14, cesip: '953UAUI16', oldCusip: '953UAU116', cesipChange: '1/10/2024', loanXID: '', dealCode: '', localCurrency: 'USD', investmentTypeCode: 'BL', investmentTypeDescription: 'Bank Loan', clientName: 'LINE OF CREDIT (ALLYUSD)', clientDescription: 'ALLY LOC' },
    { id: 15, cesip: '954CF2908', oldCusip: '954CF2908', cesipChange: '4/23/2024', loanXID: '', dealCode: '', localCurrency: 'USD', investmentTypeCode: 'BL', investmentTypeDescription: 'Bank Loan', clientName: 'LINE OF CREDIT (MACQ SALT)', clientDescription: '2020 REVOLVER' },
    { id: 16, cesip: '967FEZ08', oldCusip: '967FEZ8', cesipChange: '10/3/2020', loanXID: '', dealCode: '', localCurrency: 'USD', investmentTypeCode: 'BL', investmentTypeDescription: 'Bank Loan', clientName: 'RPX CORP', clientDescription: 'DELAYED DRAW TERM LOANE' },
    { id: 17, cesip: 'BA0000X59', oldCusip: 'BA0000X59', cesipChange: '1/16/2024', loanXID: '', dealCode: '', localCurrency: 'USD', investmentTypeCode: 'BL', investmentTypeDescription: 'Bank Loan', clientName: 'TCFI OWL BUYER LLC', clientDescription: '2024 13TH AMEND INCREMENTAL TL' },
    { id: 18, cesip: 'BA0003DV8', oldCusip: 'BA0003DV8', cesipChange: '4/15/2024', loanXID: '', dealCode: '', localCurrency: 'USD', investmentTypeCode: 'BL', investmentTypeDescription: 'Bank Loan', clientName: 'SALT DENTAL COLLECTIVE LLC', clientDescription: 'DELAYED DRAW TERM LOAN' },
    { id: 19, cesip: '64077LADS', oldCusip: '64077LADS', cesipChange: '2/1/2024', loanXID: '', dealCode: '', localCurrency: 'USD', investmentTypeCode: 'BL', investmentTypeDescription: 'Bank Loan', clientName: 'NEPTUNE PLATFORM BUYER', clientDescription: 'TERM LOAN' },
    { id: 20, cesip: '941WGRI8', oldCusip: '$41WGRIS', cesipChange: '9/15/2021', loanXID: '', dealCode: '', localCurrency: 'USD', investmentTypeCode: 'BL', investmentTypeDescription: 'Bank Loan', clientName: 'BLUEHALO FINANCING', clientDescription: '2021 TERM LOAN' },
    { id: 21, cesip: '942YNLI', oldCusip: '$42YNLUS', cesipChange: '7/2/2021', loanXID: '', dealCode: '', localCurrency: 'USD', investmentTypeCode: 'BL', investmentTypeDescription: 'Bank Loan', clientName: 'VRC COMPANIES LLC', clientDescription: '2021 TERM LOAN' },
  ];
  

const Securities: React.FC = () => {
  const [rows, setRows] = useState<GridRowsProp>(initialData);

  const loadActive = () => {
    setRows(initialData.filter((security) => security.localCurrency === 'USD')); // Example filter based on localCurrency
  };

  const loadAll = () => {
    setRows(initialData);
  };

  const columns: GridColDef[] = [
    { field: 'id', headerName: 'Id', width: 90, sortable: false },
    { field: 'cesip', headerName: 'Cesip', width: 150, sortable: false },
    { field: 'oldCusip', headerName: 'Old Cusip', width: 150, sortable: false },
    { field: 'cesipChange', headerName: 'Cesip Change', width: 150, sortable: false },
    { field: 'loanXID', headerName: 'LoanX ID', width: 150, sortable: false },
    { field: 'dealCode', headerName: 'Deal Code', width: 150, sortable: false },
    { field: 'localCurrency', headerName: 'Local Currency', width: 150, sortable: false },
    { field: 'investmentTypeCode', headerName: 'Investment Type Code', width: 150, sortable: false },
    { field: 'investmentTypeDescription', headerName: 'Investment Type Description', width: 200, sortable: false },
    { field: 'clientName', headerName: 'Client Name', width: 200, sortable: false },
    { field: 'clientDescription', headerName: 'Client Description', width: 250, sortable: false },
  ];

  return (
    <div>
      <Header title={'Mapping - Securities'} />
      <div style={{ margin: '0 10px' }}>
        <ButtonGroup variant='contained' style={{ marginBottom: '20px' }}>
          <Button onClick={loadActive}>Load Active</Button>
          <Button onClick={loadAll}>Load All</Button>
          <Button>Sort</Button>
          <Button>Validate</Button>
          <Button>View Security Tag</Button>
        </ButtonGroup>

        <DataGrid rows={rows} columns={columns} hideFooter disableColumnMenu />
      </div>
    </div>
  );
};

export default Securities;
