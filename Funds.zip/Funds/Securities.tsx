import React, { useState } from 'react';
import { DataGrid, GridColDef, GridRowsProp } from '@mui/x-data-grid';
import { ButtonGroup, Button } from '@mui/material';
import Header from './Header';
import initialData from './data/securitiesData.json';

interface Security {
  id: number;
  cesip: string;
  oldCusip: string;
  cesipChange: string;
  loanXID: string;
  dealCode: string;
  localCurrency: string;
  investmentTypeCode: string;
  investmentTypeDescription: string;
  clientName: string;
  clientDescription: string;
}


  const Securities: React.FC = () => {
  const [rows, setRows] = useState<GridRowsProp>(initialData);

  const loadActive = () => {
    setRows(initialData.filter((security) => security.localCurrency === 'USD')); // Example filter based on localCurrency
  };

  const loadAll = () => {
    setRows(initialData);
  };

  const columns: GridColDef[] = [
    { field: 'id', headerName: 'Id', width: 90, sortable: false },
    { field: 'cesip', headerName: 'Cesip', width: 150, sortable: false },
    { field: 'oldCusip', headerName: 'Old Cusip', width: 150, sortable: false },
    { field: 'cesipChange', headerName: 'Cesip Change', width: 150, sortable: false },
    { field: 'loanXID', headerName: 'LoanX ID', width: 150, sortable: false },
    { field: 'dealCode', headerName: 'Deal Code', width: 150, sortable: false },
    { field: 'localCurrency', headerName: 'Local Currency', width: 150, sortable: false },
    { field: 'investmentTypeCode', headerName: 'Investment Type Code', width: 150, sortable: false },
    { field: 'investmentTypeDescription', headerName: 'Investment Type Description', width: 200, sortable: false },
    { field: 'clientName', headerName: 'Client Name', width: 200, sortable: false },
    { field: 'clientDescription', headerName: 'Client Description', width: 250, sortable: false },
  ];

  return (
    <div>
      <Header title={'Mapping - Securities'} />
      <div style={{ margin: '0 10px' }}>
        <ButtonGroup variant='contained' style={{ marginBottom: '20px' }}>
          <Button onClick={loadActive}>Load Active</Button>
          <Button onClick={loadAll}>Load All</Button>
          <Button>Sort</Button>
          <Button>Validate</Button>
          <Button>View Security Tag</Button>
        </ButtonGroup>

        <DataGrid rows={rows} columns={columns} hideFooter disableColumnMenu />
      </div>
    </div>
  );
};

export default Securities;
