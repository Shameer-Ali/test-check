import React, { useState } from 'react';
import { DataGrid, GridColDef, GridRowsProp } from '@mui/x-data-grid';
import { ButtonGroup, Button } from '@mui/material';
import Header from './Header';
import initialData from './data/transactionData.json';

interface Transaction {
  id: number;
  sourceType: string;
  priority: number;
  role: string;
  comment: string;
  parValueRole: string;
  costValueRole: string;
  roleCategories: string;
  costPerPayment: boolean;
}

const Transactions: React.FC = () => {
  const [rows, setRows] = useState<GridRowsProp>(initialData);

  const loadActive = () => {
    setRows(initialData.filter((transaction) => transaction.costPerPayment)); // Example filter based on costPerPayment
  };

  const loadInActive = () => {
    setRows(initialData.filter((transaction) => !transaction.costPerPayment)); // Example filter based on costPerPayment
  };

  const loadAll = () => {
    setRows(initialData);
  };

  const columns: GridColDef[] = [
    { field: 'id', headerName: 'Id', width: 90, sortable: false },
    { field: 'sourceType', headerName: 'Source Type', width: 150, sortable: false },
    { field: 'priority', headerName: 'Priority', width: 100, sortable: false, type: 'number' },
    { field: 'role', headerName: 'Role', width: 150, type: 'singleSelect', valueOptions: ['SELL', 'BUY'] },
    { field: 'comment', headerName: 'Comment', width: 250 },
    { field: 'parValueRole', headerName: 'Par Value Role', width: 150, type: 'singleSelect', valueOptions: ['0', '@SHPR'] },
    { field: 'costValueRole', headerName: 'Cost Value Role', width: 150, type: 'singleSelect', valueOptions: ['0', '@SHPR', '@CYCL'] },
    { field: 'roleCategories', headerName: 'Role Categories', width: 200, type: 'singleSelect', valueOptions: ['Ignore', 'Scheduled Paydowns'] },
    { field: 'costPerPayment', headerName: 'Cost Per Payment', width: 150, type: 'boolean', renderCell: (params) => (params.value ? "True" : "False") },
  ];

  return (
    <div>
      <Header title={'Mapping - Transactions'} />
      <div style={{ margin: '0 10px' }}>
        <ButtonGroup variant='contained' style={{ marginBottom: '20px' }}>
          <Button onClick={loadActive}>Load Active</Button>
          <Button onClick={loadInActive}>Load Inactive</Button>
          <Button onClick={loadAll}>Load All</Button>
          <Button>Sort</Button>
          <Button>Validate</Button>
          <Button>View Role Tag</Button>
        </ButtonGroup>

        <DataGrid rows={rows} columns={columns} hideFooter disableColumnMenu />
      </div>
    </div>
  );
};

export default Transactions;
