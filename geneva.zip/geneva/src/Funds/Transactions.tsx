import React, { useState } from 'react';
import { DataGrid, GridColDef, GridRowsProp } from '@mui/x-data-grid';
import { ButtonGroup, Button } from '@mui/material';
import Header from './Header';

interface Transaction {
  id: number;
  sourceType: string;
  priority: number;
  role: string;
  comment: string;
  parValueRole: string;
  costValueRole: string;
  roleCategories: string;
  costPerPayment: boolean;
}

const initialData: Transaction[] = [
    { id: 1, sourceType: 'Trade', priority: 0, role: 'SELL', comment: 'Exchange Short Transactions', parValueRole: '0', costValueRole: '0', roleCategories: 'Ignore', costPerPayment: true },
    { id: 2, sourceType: 'Trade', priority: 1, role: 'BUY', comment: 'Security Claimloss', parValueRole: '@SHPR', costValueRole: '@SHPR', roleCategories: 'Scheduled Paydowns', costPerPayment: false },
    { id: 3, sourceType: 'Trade', priority: 2, role: 'SELL', comment: 'Scheduled Paydowns', parValueRole: '0', costValueRole: '@CYCL', roleCategories: 'Ignore', costPerPayment: true },
    { id: 4, sourceType: 'Trade', priority: 3, role: 'BUY', comment: 'Exchange Short Transactions', parValueRole: '@SHPR', costValueRole: '0', roleCategories: 'Scheduled Paydowns', costPerPayment: false },
    { id: 5, sourceType: 'Trade', priority: 0, role: 'SELL', comment: 'Security Claimloss', parValueRole: '0', costValueRole: '@CYCL', roleCategories: 'Ignore', costPerPayment: true },
    { id: 6, sourceType: 'Trade', priority: 1, role: 'BUY', comment: 'Scheduled Paydowns', parValueRole: '@SHPR', costValueRole: '@SHPR', roleCategories: 'Scheduled Paydowns', costPerPayment: false },
    { id: 7, sourceType: 'Trade', priority: 2, role: 'SELL', comment: 'Exchange Short Transactions', parValueRole: '0', costValueRole: '0', roleCategories: 'Ignore', costPerPayment: true },
    { id: 8, sourceType: 'Trade', priority: 3, role: 'BUY', comment: 'Security Claimloss', parValueRole: '@SHPR', costValueRole: '@CYCL', roleCategories: 'Scheduled Paydowns', costPerPayment: false },
    { id: 9, sourceType: 'Trade', priority: 0, role: 'SELL', comment: 'Scheduled Paydowns', parValueRole: '0', costValueRole: '@SHPR', roleCategories: 'Ignore', costPerPayment: true },
    { id: 10, sourceType: 'Trade', priority: 1, role: 'BUY', comment: 'Exchange Short Transactions', parValueRole: '@SHPR', costValueRole: '0', roleCategories: 'Scheduled Paydowns', costPerPayment: false },
];

const Transactions: React.FC = () => {
  const [rows, setRows] = useState<GridRowsProp>(initialData);

  const loadActive = () => {
    setRows(initialData.filter((transaction) => transaction.costPerPayment)); // Example filter based on costPerPayment
  };

  const loadInActive = () => {
    setRows(initialData.filter((transaction) => !transaction.costPerPayment)); // Example filter based on costPerPayment
  };

  const loadAll = () => {
    setRows(initialData);
  };

  const columns: GridColDef[] = [
    { field: 'id', headerName: 'Id', width: 90, sortable: false },
    { field: 'sourceType', headerName: 'Source Type', width: 150, sortable: false },
    { field: 'priority', headerName: 'Priority', width: 100, sortable: false, type: 'number' },
    { field: 'role', headerName: 'Role', width: 150, type: 'singleSelect', valueOptions: ['SELL', 'BUY'] },
    { field: 'comment', headerName: 'Comment', width: 250 },
    { field: 'parValueRole', headerName: 'Par Value Role', width: 150, type: 'singleSelect', valueOptions: ['0', '@SHPR'] },
    { field: 'costValueRole', headerName: 'Cost Value Role', width: 150, type: 'singleSelect', valueOptions: ['0', '@SHPR', '@CYCL'] },
    { field: 'roleCategories', headerName: 'Role Categories', width: 200, type: 'singleSelect', valueOptions: ['Ignore', 'Scheduled Paydowns'] },
    { field: 'costPerPayment', headerName: 'Cost Per Payment', width: 150, type: 'boolean', renderCell: (params) => (params.value ? "True" : "False") },
  ];

  return (
    <div>
      <Header title={'Mapping - Transactions'} />
      <div style={{ margin: '0 10px' }}>
        <ButtonGroup variant='contained' style={{ marginBottom: '20px' }}>
          <Button onClick={loadActive}>Load Active</Button>
          <Button onClick={loadInActive}>Load Inactive</Button>
          <Button onClick={loadAll}>Load All</Button>
          <Button>Sort</Button>
          <Button>Validate</Button>
          <Button>View Role Tag</Button>
        </ButtonGroup>

        <DataGrid rows={rows} columns={columns} hideFooter disableColumnMenu />
      </div>
    </div>
  );
};

export default Transactions;
