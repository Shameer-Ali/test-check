import Header from '../Funds/Header'
import { DataGrid } from '@mui/x-data-grid';
import { Link } from '@mui/material';

// Define a function to generate random investment policies and descriptions
const investmentPolicies = [
    'Investment Policy A',
    'Investment Policy B',
    'Investment Policy C',
    'Investment Policy D',
    'Investment Policy E',
    'Investment Policy F',
    'Investment Policy G',
    'Investment Policy H',
    'Investment Policy I',
    'Investment Policy J',
];

const descriptions = [
    'Investment description 1',
    'Investment description 2',
    'Investment description 3',
    'Investment description 4',
    'Investment description 5',
    'Investment description 6',
    'Investment description 7',
    'Investment description 8',
    'Investment description 9',
    'Investment description 10',
];

// Function to generate 10 rows of data
const generateRows = (numRows = 10) => {
    const rows = [];

    for (let i = 1; i <= numRows; i++) {
        rows.push({
            id: i,
            fund: 'WLCD',
            cusip: `938CVBII${i}`,
            baseCurrency: 'USD',
            localCurrency: 'USD',
            side: '',
            dealCode: '',
            investment: investmentPolicies[i % investmentPolicies.length],
            description: descriptions[i % descriptions.length],
            adjustedBeginningPar: 0.00,
            beginningPar: 0.00,
            purchases: '100000000',
            purchasesLessUnfunded: Math.floor(Math.random() * 10000) + 1000, // Random number for Purchases Less Unfunded
            sales: 0.00,
            salesLessUnfunded: 0.00,
            scheduledPaydowns: 0.00,
            unscheduledPaydowns: 0.00,
            pik: 0.00,
            assignmentsIn: 0.00,
            assignmentsOut: 0.00,
            restructuringIn: 0.00,
            restructuringOut: 0.00,
            cusipChange: 0.00,
            ddtlRevDrawdown: 0.00,
            ddtlRevPaydown: 0.00,
            other: 0.00,
            endingPar: 0.00,
            endingUnfunded: 0.00,
            adjustedEndingPar: 0.00,
            systemEnding: 0.00,
            difference: 0.00,
            beginningUnfunded: 0.00,
            purchasesUnfunded: 0.00,
            salesUnfunded: 0.00,
            drawdownsPaydowns: 0.00,
            systemEndingUnfunded: 0.00,
            fxRate: 0.00,
            basePar: 0.00,
            comments: '',
        });
    }

    return rows;
};

// Define columns as before
const columns = [
    { field: 'fund', headerName: 'Fund', width: 150 },
    { field: 'cusip', headerName: 'Cusip', width: 150 },
    { field: 'baseCurrency', headerName: 'Base Currency', width: 150 },
    { field: 'localCurrency', headerName: 'Local Currency', width: 150 },
    { field: 'side', headerName: 'Side', width: 150 },
    { field: 'dealCode', headerName: 'Deal Code', width: 150 },
    { field: 'investment', headerName: 'Investment', width: 200 },
    { field: 'description', headerName: 'Description/Type', width: 250 },
    { field: 'adjustedBeginningPar', headerName: 'Adjusted Beginning Par', width: 200 },
    { field: 'beginningPar', headerName: 'Beginning Par', width: 150 },
    {
        field: 'purchases',
        headerName: 'Purchases',
        width: 150,
        renderCell: (params: any) => (
            <Link href="#" onClick={(e) => e.preventDefault()}>
                {params.value}
            </Link>
        )
    },
    { field: 'purchasesLessUnfunded', headerName: 'Purchases Less Unfunded', width: 200 },
    { field: 'sales', headerName: 'Sales', width: 150 },
    { field: 'salesLessUnfunded', headerName: 'Sales Less Unfunded', width: 200 },
    { field: 'scheduledPaydowns', headerName: 'Scheduled Paydowns', width: 200 },
    { field: 'unscheduledPaydowns', headerName: 'Unscheduled Paydowns', width: 200 },
    { field: 'pik', headerName: 'PIK', width: 150 },
    { field: 'assignmentsIn', headerName: 'Assignments In', width: 200 },
    { field: 'assignmentsOut', headerName: 'Assignments Out', width: 200 },
    { field: 'restructuringIn', headerName: 'Restructuring In', width: 200 },
    { field: 'restructuringOut', headerName: 'Restructuring Out', width: 200 },
    { field: 'cusipChange', headerName: 'Cusip Change', width: 150 },
    { field: 'ddtlRevDrawdown', headerName: 'DDTL / Rev Drawdown', width: 200 },
    { field: 'ddtlRevPaydown', headerName: 'DDTL / Rev Paydown', width: 200 },
    { field: 'other', headerName: 'Other', width: 150 },
    { field: 'endingPar', headerName: 'Ending Par', width: 150 },
    { field: 'endingUnfunded', headerName: 'Ending Unfunded', width: 200 },
    { field: 'adjustedEndingPar', headerName: 'Adjusted Ending Par', width: 200 },
    { field: 'systemEnding', headerName: 'System Ending', width: 200 },
    { field: 'difference', headerName: 'Difference', width: 150 },
    { field: 'beginningUnfunded', headerName: 'Beginning Unfunded', width: 200 },
    { field: 'purchasesUnfunded', headerName: 'Purchases Unfunded', width: 200 },
    { field: 'salesUnfunded', headerName: 'Sales Unfunded', width: 200 },
    { field: 'drawdownsPaydowns', headerName: 'Drawdowns & Paydowns', width: 200 },
    { field: 'systemEndingUnfunded', headerName: 'System Ending Unfunded', width: 200 },
    { field: 'fxRate', headerName: 'Period End FX Rate', width: 200 },
    { field: 'basePar', headerName: 'Base Par', width: 150 },
    { field: 'comments', headerName: 'Comments:', width: 200 },
];

export default function Par() {
    // Generate 10 rows
    const rows = generateRows(10);

    return (
        <div>
            <Header title={'Mapping - Securities'} />
            <DataGrid rows={rows} columns={columns} hideFooter disableColumnMenu  />
        </div>
    );
}
