import React, { useState, useEffect } from 'react'; 
import { Box, Typography, Drawer, Accordion, AccordionSummary, AccordionDetails, List, ListItem, ListItemText } from '@mui/material';
import { BrowserRouter as Router, Routes, Route, useNavigate, useLocation } from 'react-router-dom';
import Header from './Funds/Header';
import FundDetailsTable from './Funds/FundDetailsTable';
import Securities from './Funds/Securities';
import Transactions from './Funds/Transactions';
import Exclusions from './Funds/Exclusions';
import Par from './Rolls/Par';
import Income from './Rolls/Income';
import Cost from './Rolls/Cost';

const LayoutComponent: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [selectedIndex, setSelectedIndex] = useState<number | null>(null);

  const menuItems = {
    rolls: [
      { text: 'Par Roll', path: '/par' },
      { text: 'Cost Roll', path: '/cost' },
      { text: 'Income Roll', path: '/income' },
    ],
    funds: [
      { text: 'Funds', path: '/funds' },
      { text: 'Securities', path: '/securities' },
      { text: 'Transactions', path: '/transactions' },
      { text: 'Exclusions', path: '/exclusions' },
    ]
  };

  useEffect(() => {
    const path = location.pathname;

    // Find the corresponding index for the path in rolls or funds menu
    const findIndex = (items: { text: string; path: string }[]) => items.findIndex(item => item.path === path);

    const rollIndex = findIndex(menuItems.rolls);
    const fundIndex = findIndex(menuItems.funds);

    if (rollIndex !== -1) setSelectedIndex(rollIndex);
    else if (fundIndex !== -1) setSelectedIndex(fundIndex + menuItems.rolls.length);  // Offset fund index by roll items
    else setSelectedIndex(null);  // Reset if no match
  }, [location.pathname]);

  const handleListItemClick = (index: number, path: string) => {
    setSelectedIndex(index);
    navigate(path);  // Update the URL
  };

  return (
    <Box sx={{ display: 'flex', flexDirection: 'column', height: '100vh' }}>
      {/* Fixed header */}
      <Box
        sx={{
          backgroundColor: '#001AFF',
          color: '#FFF',
          p: 2,
          textAlign: 'center',
          position: 'fixed',
          top: 0,
          left: 0,
          width: '100%',
          zIndex: 1000,
          display: 'flex',
          alignItems: 'center',
          gap: 2, // space between logo and text
        }}
      >
        <div style={{ background: "#fff", padding: "5px" }}>
          <img
            src="https://www.statestreet.com/web/Homepage/images/state-street-logo-final.svg"
            alt="State Street Logo"
            style={{ height: '40px' }} // Adjust height as needed
          />
        </div>
        <Typography variant="h4" component="div">
          Blue State Street
        </Typography>
      </Box>

      {/* Main content with permanently open drawer and content area */}
      <Box sx={{ display: 'flex', flexGrow: 1, marginTop: '72px' }}>
        <Drawer
          variant="permanent"
          sx={{
            width: 240,
            flexShrink: 0,
            [`& .MuiDrawer-paper`]: { width: 240, boxSizing: 'border-box', marginTop: '87px' },
          }}
        >
          {/* Accordion wrapping List */}
          <Accordion defaultExpanded>
            <AccordionSummary expandIcon={"v"}>
              <Typography>Rolls</Typography>
            </AccordionSummary>
            <AccordionDetails>
              <List>
                {menuItems.rolls.map((item, index) => (
                  <ListItem
                    button
                    key={item.text}
                    selected={selectedIndex === index}
                    onClick={() => handleListItemClick(index, item.path)}
                  >
                    <ListItemText primary={item.text} />
                  </ListItem>
                ))}
              </List>
            </AccordionDetails>
          </Accordion>
          <Accordion defaultExpanded>
            <AccordionSummary expandIcon={"v"}>
              <Typography>Mapping Funds</Typography>
            </AccordionSummary>
            <AccordionDetails>
              <List>
                {menuItems.funds.map((item, index) => (
                  <ListItem
                    button
                    key={item.text}
                    selected={selectedIndex === index + menuItems.rolls.length}
                    onClick={() => handleListItemClick(index + menuItems.rolls.length, item.path)}
                  >
                    <ListItemText primary={item.text} />
                  </ListItem>
                ))}
              </List>
            </AccordionDetails>
          </Accordion>
        </Drawer>

        {/* Content area that changes based on the route */}
        <Box sx={{ flexGrow: 1 }}>
          <Routes>
            <Route path="/" element={<Header title={'Main Content'} />} />
            <Route path="/funds" element={<FundDetailsTable />} />
            <Route path="/securities" element={<Securities />} />
            <Route path="/transactions" element={<Transactions />} />
            <Route path="/exclusions" element={<Exclusions />} />
            <Route path="/par" element={<Par />} />
            <Route path="/cost" element={<Cost />} />
            <Route path="/income" element={<Income />} />
          </Routes>
        </Box>
      </Box>
    </Box>
  );
};

const App: React.FC = () => (
  <Router>
    <LayoutComponent />
  </Router>
);

export default App;
