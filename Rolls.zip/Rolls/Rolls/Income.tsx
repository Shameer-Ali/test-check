import EmptyTable from './TempEmptyTable'
import Header from '../Funds/Header'

const Income = () => {
    return (
        <div>
            <Header title={'Income Roll'} />
            <EmptyTable />
        </div>
    )
}

export default Income