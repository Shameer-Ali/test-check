import EmptyTable from './TempEmptyTable'
import Header from '../Funds/Header'

const Cost = () => {
    return (
        <div>
            <Header title={'Cost Roll'} />
            <EmptyTable />
        </div>
    )
}

export default Cost