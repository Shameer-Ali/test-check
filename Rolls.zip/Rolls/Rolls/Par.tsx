import EmptyTable from './TempEmptyTable'
import Header from '../Funds/Header'

const Par = () => {
    return (
        <div>
            <Header title={'Par Roll'} />
            <EmptyTable />
        </div>
    )
}

export default Par