import React, { useState, MouseEvent } from 'react';
import { DataGrid, GridColDef, GridRowsProp, GridCellParams } from '@mui/x-data-grid';
import { ButtonGroup, Button, Menu, MenuItem, IconButton } from '@mui/material';
import { FaEdit } from 'react-icons/fa';
import Header from './Header';

interface Fund {
    id: number;
    fundId: string;
    baseCurrency: string;
    fundDescription: string;
    fundType: string;
    compositeId: string;
    isActive: boolean;
}

const initialData: Fund[] = [
    {
        id: 1,
        fundId: 'WLCD',
        baseCurrency: 'USD',
        fundDescription: 'Willow Tree Capital Fund',
        fundType: 'Composite',
        compositeId: 'WLCD',
        isActive: true,
    },
    {
        id: 2,
        fundId: 'WLCH',
        baseCurrency: 'USD',
        fundDescription: 'Willow Tree Capital Fund CH',
        fundType: 'Sleeve',
        compositeId: 'WLCD',
        isActive: false,
    },
    {
        id: 3,
        fundId: 'WLCG',
        baseCurrency: 'Willow Tree Capital Fund G',
        fundDescription: 'Fund 3',
        fundType: 'Standard',
        compositeId: 'WLCD',
        isActive: true,
    },
    {
        id: 4,
        baseCurrency: 'USD',
        fundDescription: 'Willow Tree Capital Fund C',
        fundId: 'WLCC',
        fundType: 'Composite',
        compositeId: 'WLCD',
        isActive: false,
    },
    {
        id: 5,
        baseCurrency: 'USD',
        fundDescription: 'Willow Tree Capital Fund A',
        fundId: 'WLDA',
        fundType: 'Sleeve',
        compositeId: 'WLCD',
        isActive: true,
    },
    {
        id: 6,
        baseCurrency: 'USD',
        fundDescription: 'Willow Tree Capital Fund F',
        fundId: 'WLDF',
        fundType: 'Standard',
        compositeId: 'WLCD',
        isActive: false,
    },
    {
        id: 7,
        baseCurrency: 'USD',
        fundDescription: 'Willow Tree Capital Fund M',
        fundId: 'WLDM',
        fundType: 'Standard',
        compositeId: 'WLCD',
        isActive: true,
    },
    {
        id: 8,
        baseCurrency: 'USD',
        fundDescription: 'Willow Tree Capital Fund K',
        fundId: 'WLDK',
        fundType: 'Standard',
        compositeId: 'WLCD',
        isActive: false,
    },
    {
        id: 9,
        baseCurrency: 'USD',
        fundDescription: 'Willow Tree Capital Fund P',
        fundId: 'WLDO',
        fundType: 'Composite',
        compositeId: 'WLCD',
        isActive: true,
    },
    {
        id: 10,
        baseCurrency: 'USD',
        fundDescription: 'Willow Tree Capital Fund O',
        fundId: 'WLZO',
        fundType: 'Sleev',
        compositeId: 'WLCD',
        isActive: false,
    },
];

const FundDetailsTable: React.FC = () => {
    const [rows, setRows] = useState<GridRowsProp>(initialData);
    const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
    const [selectedRow, setSelectedRow] = useState<Fund | null>(null);

    const loadActive = () => {
        setRows(initialData.filter((fund) => fund.isActive));
    };

    const loadInActive = () => {
        setRows(initialData.filter((fund) => !fund.isActive));
    };

    const loadAll = () => {
        setRows(initialData);
    };

    const sortData = () => {
        const sortedData = [...rows].sort((a, b) =>
            a.fundId.localeCompare(b.fundId)
        );
        setRows(sortedData);
    };

    const clearData = () => {
        setRows(initialData);
    };

    const handleContextMenu = (event: MouseEvent<HTMLElement>, row: Fund) => {
        event.preventDefault();
        setAnchorEl(event.currentTarget);
        setSelectedRow(row);
    };

    const handleClose = () => {
        setAnchorEl(null);
    };

    const handleMenuItemClick = (isActive: boolean) => {
        if (selectedRow) {
            const updatedRows = rows.map(row =>
                row.id === selectedRow.id ? { ...row, isActive } : row
            );
            setRows(updatedRows);
        }
        handleClose();
    };

    const columns: GridColDef[] = [
        {
            field: 'id',
            headerName: 'ID',
            width: 90,
            sortable: false,
            editable: true,
        },
        {
            field: 'fundId',
            headerName: 'Fund Id',
            width: 150,
            sortable: false,
            editable: true,
        },
        {
            field: 'baseCurrency',
            headerName: 'Base Currency',
            width: 150,
            sortable: false,
            editable: true,
        },
        {
            field: 'fundDescription',
            headerName: 'Fund Description',
            width: 200,
            sortable: false,
            editable: true,
        },
        {
            field: 'fundType',
            headerName: 'Fund Type',
            width: 150,
            editable: true,
            type: 'singleSelect',
            valueOptions: ['composite', 'sleeve', 'standard'],
        },
        {
            field: 'compositeId',
            headerName: 'Composite Id',
            width: 150,
            sortable: false,
            editable: true,
        },
        {
            field: 'isActive',
            headerName: 'Is Active',
            width: 150,
            renderCell: (params: GridCellParams) => (
                <div
                    onContextMenu={(e) => handleContextMenu(e, params.row)}
                    style={{ display: 'flex', alignItems: 'center', cursor: 'context-menu' }}
                >
                    <span>{params.row.isActive ? 'True' : 'False'}</span>
                    <IconButton
                        style={{ marginLeft: '8px' }}
                        onClick={(e) => handleContextMenu(e, params.row)}
                        size="small"
                    >
                        <FaEdit />
                    </IconButton>
                </div>
            ),
            editable: true,
        },
    ];

    return (
        <div>
            <Header title={'Mapping - Funds'} />
            <ButtonGroup variant="outlined" style={{ marginBottom: '20px' }}>
                <Button onClick={loadActive}>Load Active</Button>
                <Button onClick={loadInActive}>Load In Active</Button>
                <Button onClick={loadAll}>Load All</Button>
                <Button onClick={sortData}>Sort</Button>
                <Button onClick={clearData}>Clear</Button>
            </ButtonGroup>

            <DataGrid rows={rows} columns={columns} hideFooter disableColumnMenu />

            <Menu
                anchorEl={anchorEl}
                open={Boolean(anchorEl)}
                onClose={handleClose}
            >
                <MenuItem onClick={() => handleMenuItemClick(true)}>True</MenuItem>
                <MenuItem onClick={() => handleMenuItemClick(false)}>False</MenuItem>
            </Menu>
        </div>
    );
};

export default FundDetailsTable;
